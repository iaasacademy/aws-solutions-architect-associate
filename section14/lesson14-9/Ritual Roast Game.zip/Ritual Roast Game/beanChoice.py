def lambda_handler(event, context):
    session = event.get("session", {}) or {}
    user = event.get("userInput", {}) or {}
    choice = (user.get("choice") or "").upper()

    if choice not in ("ARABICA", "ROBUSTA"):
        # Keep them on same step with a helpful prompt
        session["step"] = "BEAN_CHOICE"
        return {
            "session": session,
            "prompt": "Invalid bean. Choose ARABICA or ROBUSTA."
        }

    session["bean"] = "Arabica" if choice == "ARABICA" else "Robusta"
    session["step"] = "ROAST_CHOICE"
    return {
        "session": session,
        "prompt": f"{session['bean']} selected. Roast: LIGHT or DARK?"
    }