def lambda_handler(event, context):
    session = event.get("session", {}) or {}
    session["step"] = "BEAN_CHOICE"
    session["done"] = False
    return {
        "session": session,
        "prompt": "Choose your beans: ARABICA or ROBUSTA?"
    }