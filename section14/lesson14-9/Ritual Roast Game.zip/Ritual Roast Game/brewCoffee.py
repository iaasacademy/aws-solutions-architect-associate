def lambda_handler(event, context):
    session = event.get("session", {}) or {}
    user = event.get("userInput", {}) or {}
    roast = (user.get("roast") or user.get("choice") or "").upper()  # UI may send "roast" or "choice"

    if roast not in ("LIGHT", "DARK"):
        session["step"] = "ROAST_CHOICE"
        return {
            "session": session,
            "prompt": "Invalid roast. Choose LIGHT or DARK."
        }

    session["roast"] = "LIGHT" if roast == "LIGHT" else "DARK"

    if session.get("bean") == "Arabica" and session["roast"] == "LIGHT":
        outcome = {"result": "WIN", "message": "Silky Arabica latte — perfection! ☕✨"}
    elif session.get("bean") == "Robusta" and session["roast"] == "DARK":
        outcome = {"result": "WIN", "message": "Punchy Robusta espresso — boom! 💥☕"}
    else:
        outcome = {"result": "LOSE", "message": "Over-extracted disaster… try again 😬"}

    session["done"] = True
    return {
        "session": session,
        "outcome": outcome
    }