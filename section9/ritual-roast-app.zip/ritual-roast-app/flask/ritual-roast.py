from flask import Flask, jsonify, request, send_from_directory
import mysql.connector
import os
from flask_cors import CORS
import boto3
import json

# Function to fetch MySQL secrets from AWS Secrets Manager
def get_mysql_database_secrets():
    session = boto3.Session()
    client = session.client(service_name="secretsmanager", region_name="eu-west-2")

    get_secret_value_response = client.get_secret_value(SecretId="testdb-mysql-secret")
    secret_string = json.loads(get_secret_value_response["SecretString"])

    return [
        secret_string["host"],
        secret_string["username"],
        secret_string["password"],
        secret_string["dbname"],
        secret_string["port"]
    ]

app = Flask(
    __name__,
    static_folder="ritual_roast/build/static",
    template_folder="ritual_roast/build"
)
CORS(app, resources={r"/*": {"origins": "*"}})

# Initialize DB connection
secrets = get_mysql_database_secrets()
connection = mysql.connector.connect(
    host=secrets[0],
    user=secrets[1],
    password=secrets[2],
    database=secrets[3],
    port=secrets[4]
)
cursor = connection.cursor()

# Create the recipes table if it doesn't exist
query = """
CREATE TABLE IF NOT EXISTS recipes (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    email VARCHAR(255) NOT NULL,
    recipe_name VARCHAR(255) NOT NULL,
    description TEXT,
    ingredients TEXT,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
);
"""
cursor.execute(query)
connection.commit()

# Function to check and reconnect to the DB with updated secrets
def check_and_reconnect():
    global connection, cursor
    try:
        connection.ping(reconnect=True, attempts=3, delay=2)
    except mysql.connector.Error:
        print("Reconnecting to database with updated secrets...")
        secrets = get_mysql_database_secrets()
        connection = mysql.connector.connect(
            host=secrets[0],
            user=secrets[1],
            password=secrets[2],
            database=secrets[3],
            port=secrets[4]
        )
        cursor = connection.cursor()

# API to retrieve all recipes
@app.route('/get_recipe', methods=['GET'])
def get_recipes():
    check_and_reconnect()
    query = "SELECT * FROM recipes ORDER BY id DESC;"
    cursor.execute(query)
    rows = cursor.fetchall()

    recipes = []
    for row in rows:
        recipe = {
            'id': row[0],
            'name': row[1],
            'email': row[2],
            'recipe_name': row[3],
            'description': row[4],
            'ingredients': row[5],
            'created_at': str(row[6])
        }
        recipes.append(recipe)
    return jsonify(recipes)

# API to insert a new recipe
@app.route('/add_recipe', methods=['POST'])
def add_recipe():
    check_and_reconnect()
    data = request.get_json()

    name = data.get('name')
    email = data.get('email')
    recipe_name = data.get('recipe_name')
    description = data.get('description')
    ingredients = data.get('ingredients')

    query = """
        INSERT INTO recipes (name, email, recipe_name, description, ingredients)
        VALUES (%s, %s, %s, %s, %s);
    """
    cursor.execute(query, (name, email, recipe_name, description, ingredients))
    connection.commit()

    return jsonify({'message': 'Recipe added successfully'}), 201

# Serve React frontend
@app.route("/", defaults={"path": ""})
@app.route("/<path:path>")
def serve(path):
    static_file_path = os.path.join(app.static_folder, path)
    template_file_path = os.path.join(app.template_folder, path)

    if path and os.path.exists(static_file_path):
        return send_from_directory(app.static_folder, path)
    if path and os.path.exists(template_file_path):
        return send_from_directory(app.template_folder, path)

    index_file = os.path.join(app.template_folder, "index.html")
    if os.path.exists(index_file):
        return send_from_directory(app.template_folder, "index.html")

    return "Error: index.html not found!", 404

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=False)
